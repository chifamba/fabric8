## Keycloak

This profile provisions a stand alone [Keycloak](http://keycloak.jboss.org//) authentication server running on WildFly.