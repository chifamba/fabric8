## Tomcat 7 Stand Alone

This profile uses a stand alone [Apache Tomcat](http://tomcat.apache.org/) container to run whatever web applications and services you wish to deploy.