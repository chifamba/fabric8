## HDFS

This profile lets you create an Hadoop File System 2.2 containers on your network with the role of DataNode.

Since the profile has to download ~80MB from the internet that it cannot cache, be aware that each installation might take a while.
