## Cassandra

This profile lets you create a number of Cassandra containers on your network.

Note that Cassandra uses a fixed RPC port; so if you wish to use more than one cassandra container on machine you need to use a separate listen address. If you wish to do this please see the [cassandra.local profile instead](../cassandra.local.profile)
