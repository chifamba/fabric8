## WildFly Stand Alone

This profile provisions a stand alone [WildFly](http://wildfly.org/) container to run whatever web applications and services you wish to deploy.