## Java Container Debug Profile

This profile enables remote debugging on the process in your IDE via JPDA.

To find the debug port use URLs tab in the Container page (or the container-info command in the shell).