## Jetty 9 Stand Alone

This profile uses a stand alone [Jetty](http://www.eclipse.org/jetty/) container to run whatever web applications and services you wish to deploy.