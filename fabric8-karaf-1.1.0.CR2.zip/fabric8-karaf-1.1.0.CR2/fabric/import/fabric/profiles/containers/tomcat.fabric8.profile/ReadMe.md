## Fabric8 Tomcat

This profile uses a Fabric8 distro of [Apache Tomcat](http://tomcat.apache.org/) to run whatever web applications and services you wish to deploy; including an embedded Fabric8 Agent.