## LiveOak

This profile provisions a stand alone [LiveOak](http://liveoak.io/) container to run whatever services you wish to deploy.

**Note** this service requires a running [MongoDB](http://www.mongodb.org/) server.