## Fabric DOSGi Producer

This is the producer, which exposes the DOSGi service which is used by ther consumer.

### Installing

Install this profile to a container.
And then install the consumer to another container, to facailitate Distributed OSGi services.